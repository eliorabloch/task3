task3
